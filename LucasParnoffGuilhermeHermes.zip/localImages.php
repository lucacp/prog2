<?php $OutLocal="t3/upload/";
	  $InLocal="upload/"; 
	  $OutLocalL="t3/uploadL/";
	  $InLocalL="uploadL/"; ?>