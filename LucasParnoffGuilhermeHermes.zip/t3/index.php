<?php 
	header('location:t3.php');
?>