<?php
	mysql_close($csql);
?>